from flask import Flask
from views.employees import employees_blueprint
from views.departments import departments_blueprint
from views.projects import projects_blueprint



application = Flask(__name__)
application.register_blueprint(employees_blueprint)
application.register_blueprint(departments_blueprint)
application.register_blueprint(projects_blueprint)

