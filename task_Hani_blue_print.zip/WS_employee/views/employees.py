from flask import Flask, jsonify, abort, request
from flask import Blueprint, render_template

#app = Flask(__name__)
employees_blueprint = Blueprint('employees', __name__)


employees = [
    {"id": 555, "name": "Ahmad", "birth_year": 1990}
]


###############################

@employees_blueprint.route("/employees/", methods=['GET'])
def get_employees():
    return jsonify(employees)


@employees_blueprint.route("/employees/<int:employee_id>", methods=['GET'])
def get_employee(employee_id):
    for item in employees:
        if item["id"] == employee_id:
            return jsonify(item)
    else:
        abort(404, "employee not found")


@employees_blueprint.route("/employees/", methods=['POST'])
def insert_employee():
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    employees.append(data)
    return jsonify({"message": "success"}), 201


@employees_blueprint.route("/employees/<int:employee_id>", methods=['PUT'])
def update_employee(employee_id):
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    for x in range(len(employees)):
        if employees[x]["id"] == employee_id:
            del employees[x]
            employees.append(data)
            return jsonify({"message": "success"})
    else:
        abort(404, "employee not found")


@employees_blueprint.route("/employees/<int:employee_id>", methods=['DELETE'])
def delete_employee(employee_id):
    for x in range(len(employees)):
        if employees[x]["id"] == employee_id:
            del employees[x]
            return jsonify({"message": "success"})
    else:
        abort(404, "employee not found")


###############################

@employees_blueprint.errorhandler(404)
@employees_blueprint.errorhandler(400)
def on_error(error):
    return jsonify({"message": error.description}), error.code


###############################

if __name__ == "__main__":
    employees_blueprint.run(host="0.0.0.0", port=5000, debug=True)
