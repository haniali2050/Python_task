from flask import Flask, jsonify, abort, request
from flask import Blueprint, render_template

#app = Flask(__name__)
projects_blueprint = Blueprint('projects', __name__)


projects = [
    {"id": 555, "name": "Ahmad", "birth_year": 1990}
]


###############################

@projects_blueprint.route("/projects/", methods=['GET'])
def get_projects():
    return jsonify(projects)


@projects_blueprint.route("/projects/<int:project_id>", methods=['GET'])
def get_project(project_id):
    for item in projects:
        if item["id"] == project_id:
            return jsonify(item)
    else:
        abort(404, "project not found")


@projects_blueprint.route("/projects/", methods=['POST'])
def insert_project():
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    projects.append(data)
    return jsonify({"message": "success"}), 201


@projects_blueprint.route("/projects/<int:project_id>", methods=['PUT'])
def update_project(project_id):
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    for x in range(len(projects)):
        if projects[x]["id"] == project_id:
            del projects[x]
            projects.append(data)
            return jsonify({"message": "success"})
    else:
        abort(404, "project not found")


@projects_blueprint.route("/projects/<int:project_id>", methods=['DELETE'])
def delete_project(project_id):
    for x in range(len(projects)):
        if projects[x]["id"] == project_id:
            del projects[x]
            return jsonify({"message": "success"})
    else:
        abort(404, "project not found")


###############################

@projects_blueprint.errorhandler(404)
@projects_blueprint.errorhandler(400)
def on_error(error):
    return jsonify({"message": error.description}), error.code


###############################

if __name__ == "__main__":
    projects_blueprint.run(host="0.0.0.0", port=5000, debug=True)
