from flask import Flask, jsonify, abort, request
from flask import Blueprint, render_template

#app = Flask(__name__)
departments_blueprint = Blueprint('departments', __name__)


departments = [
    {"id": 555, "name": "Ahmad", "birth_year": 1990}
]


###############################

@departments_blueprint.route("/departments/", methods=['GET'])
def get_departments():
    return jsonify(departments)


@departments_blueprint.route("/departments/<int:department_id>", methods=['GET'])
def get_department(department_id):
    for item in departments:
        if item["id"] == department_id:
            return jsonify(item)
    else:
        abort(404, "department not found")


@departments_blueprint.route("/departments/", methods=['POST'])
def insert_department():
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    departments.append(data)
    return jsonify({"message": "success"}), 201


@departments_blueprint.route("/departments/<int:department_id>", methods=['PUT'])
def update_department(department_id):
    if not request.content_type == 'application/json':
        abort(400, "content type must be application/json")
    data = request.get_json()
    for x in range(len(departments)):
        if departments[x]["id"] == department_id:
            del departments[x]
            departments.append(data)
            return jsonify({"message": "success"})
    else:
        abort(404, "department not found")


@departments_blueprint.route("/departments/<int:department_id>", methods=['DELETE'])
def delete_department(department_id):
    for x in range(len(departments)):
        if departments[x]["id"] == department_id:
            del departments[x]
            return jsonify({"message": "success"})
    else:
        abort(404, "department not found")


###############################

@departments_blueprint.errorhandler(404)
@departments_blueprint.errorhandler(400)
def on_error(error):
    return jsonify({"message": error.description}), error.code


###############################

if __name__ == "__main__":
    departments_blueprint.run(host="0.0.0.0", port=5000, debug=True)
