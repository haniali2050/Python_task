import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="test_db"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM test_tbl")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)